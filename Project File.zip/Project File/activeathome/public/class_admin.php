<?php

// Define the Admin class
class Admin {

    // Public properties for admin attributes
    public $username;
    public $name;
    public $email;

    // Constructor method that accepts an optional array of attributes
    public function __construct($args = []) {
        // Assign provided values or default values if not set
        $this->username = $args['username'] ?? 'admin'; // Default username
        $this->name = $args['name'] ?? 'System Administrator'; // Default display name
        $this->email = $args['email'] ?? 'admin@activeathome.com'; // Default email
    }

    // Static method to return a predefined admin profile
    public static function get_admin_profile() {
        // Returns a new instance of Admin with hardcoded default values
        return new Admin([
            'username' => 'admin',
            'name' => 'ActiveAtHome Admin',
            'email' => 'admin@activeathome.com'
        ]);
    }
}
