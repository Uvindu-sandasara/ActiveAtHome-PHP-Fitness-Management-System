<?php
	// Include initialization file 
	require_once('../private/initialize.php');
	$id = $_GET['id'] ?? null;

	if ($id) {
		// Find the trainer by ID
		$trainer = Trainer::find_by_id($db, $id);
		if ($trainer) {
			$success = Trainer::delete($db, $id);
			 // If deletion is successful, redirect back to the trainer list with a status
			if ($success) {
				header("Location: trainers.php?status=deleted");
				exit;
			} else {
				// If deletion failed, set an error message
				$message = "Failed to delete trainer.";
			}
		} else {
			// If trainer not found with the given ID
			$message = "Trainer not found.";
		}
	} else {
		// If no ID provided in the URL, redirect to trainers page
		header("Location: trainers.php");
		exit;
	}

	include(SHARED_PATH . '/header.php');
?>

<h2>Delete Trainer</h2>

	<!-- Display message if any (error or confirmation) -->
    <?php if (!empty($message)): ?>
    <p class="alert"><?= htmlspecialchars($message) ?></p>
    <?php else: ?>
    <p>Trainer deleted successfully.</p>
    <?php endif; ?>

<a href="trainers.php" class="btn-back">← Back to Trainer List</a>

<?php include(SHARED_PATH . '/footer.php'); ?>