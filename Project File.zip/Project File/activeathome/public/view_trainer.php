<?php
	// Include the initialization file to access database and shared path constants
	require_once('../private/initialize.php');
	// Get the trainer ID from the URL query string, or set null if not provided
	$id = $_GET['id'] ?? null;

	// Redirect to the trainer list page if no ID is passed
	if (!$id) {
		header("Location: trainers.php");
		exit;
	}

	// Fetch the trainer's details from the database using the ID
	$trainer = Trainer::find_by_id($db, $id);
	
	include(SHARED_PATH . '/header.php');
?>

<h2>Trainer Details</h2>

<?php if ($trainer): ?>

	<!-- Display trainer's details safely using htmlspecialchars to prevent XSS -->
    <p><strong>Name:</strong> <?= htmlspecialchars($trainer['name']) ?></p>
    <p><strong>Email:</strong> <?= htmlspecialchars($trainer['email']) ?></p>
    <p><strong>Location:</strong> <?= htmlspecialchars($trainer['location']) ?></p>
    <p><strong>Certifications:</strong> <?= htmlspecialchars($trainer['certifications']) ?></p>
    <p><strong>Years:</strong> <?= htmlspecialchars($trainer['years']) ?></p>
    <p><strong>Specialization:</strong> <?= htmlspecialchars($trainer['specialization']) ?></p>

	<!-- Button to go back to trainer list -->
    <a href="trainers.php" class="btn-back">← Back to Trainer List</a>
    
<?php else: ?>
	<!-- Message if no trainer found -->
    <p>Trainer not found.</p>
<?php endif; ?>

<?php include(SHARED_PATH . '/footer.php'); ?>
