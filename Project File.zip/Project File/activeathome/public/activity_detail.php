<?php
	require_once('../private/initialize.php');

	// Get list of all activities
	$activities = Activity::all($db);

	// Get selected activity if id is present in URL
	$id = $_GET['id'] ?? null;
	$selected_activity = $id ? Activity::find_by_id($db, $id) : null;

	include(SHARED_PATH . '/header.php');
?>

<!-- Main content container -->
<div class="main-content">
  <h2>Activities</h2>

  <!-- Table displaying the list of activities -->
  <table>
    <tr>
      <th>Activity Name</th>
      <th>Action</th>
    </tr>
	
	<!-- Loop through each activity and show it in a table row -->
    <?php foreach ($activities as $activity): ?>
      <tr>
		<!-- Display the activity name safely -->
        <td><?= htmlspecialchars($activity['name']) ?></td>
		<!-- View button links to the same page with activity ID in query -->
        <td><a href="activities.php?id=<?= $activity['id'] ?>">View</a></td>
      </tr>
    <?php endforeach; ?>
  </table>

  <!-- If an activity is selected, display its full details -->
  <?php if ($selected_activity): ?>
    
    <hr>
    <h3>Activity Details</h3>
	
	<!-- Show full activity details safely -->
    <p><strong>Name:</strong> <?= htmlspecialchars($selected_activity['name']) ?></p>
    <p><strong>Description:</strong><br> <?= nl2br(htmlspecialchars($selected_activity['description'])) ?></p>
    <p><strong>Benefits:</strong><br> <?= nl2br(htmlspecialchars($selected_activity['benefits'])) ?></p>
    <p><strong>Price:</strong> Rs. <?= htmlspecialchars($selected_activity['price']) ?></p>
    <br>
    <a href="activities.php" class="btn-back">← Back to Activities</a>

  <?php else: ?>
    <!-- Shown if an invalid or no ID is selected -->
    <p class="alert">Activity not found or invalid ID.</p>
  <?php endif; ?>

</div>

<?php include(SHARED_PATH . '/footer.php'); ?>
