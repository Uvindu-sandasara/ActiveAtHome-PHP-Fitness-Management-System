<?php
	require_once('../private/initialize.php');   // Include initialization file to set up database connection and paths
	$activities = Activity::all($db);   
	
	include(SHARED_PATH . '/header.php');
?>

	<!-- Page Title -->
	<h2>Activity List</h2>

	<!-- Display all activity names in a table -->
	<table>
		<tr>
			<th>Name</th>
			<th>Details</th>
		</tr>
		
		<!-- Loop through each activity and output a row in the table -->
		<?php foreach ($activities as $activity): ?>
			<tr>
				<td><?= htmlspecialchars($activity['name']) ?></td>
				<!-- Link to view full activity details -->
				<td><a href="activity_detail.php?id=<?= $activity['id'] ?>">View</a></td>
			</tr>
		<?php endforeach; ?>
	</table>

<?php include(SHARED_PATH . '/footer.php'); ?>
