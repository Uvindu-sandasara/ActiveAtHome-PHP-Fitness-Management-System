<?php
	require_once('../private/initialize.php');
	$id = $_GET['id'] ?? null;
	$message = '';

	if (!$id) {
		header("Location: trainers.php");
		exit;
	}

	$trainer = Trainer::find_by_id($db, $id);

	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		$updated_data = [
			'email' => $_POST['email'] ?? '',
			'location' => $_POST['location'] ?? '',
			'certifications' => $_POST['certifications'] ?? '',
			'years' => $_POST['years'] ?? '',
			'specialization' => $_POST['specialization'] ?? ''
		];

		if (!empty($updated_data['email']) && !empty($updated_data['location'])) {
			$success = Trainer::update($db, $id, $updated_data);
			if ($success) {
				$message = "Trainer updated successfully!";
				$trainer = Trainer::find_by_id($db, $id); // refresh data
			} else {
				$message = "Failed to update trainer.";
			}
		} else {
			$message = "All fields are required.";
		}
	}

	include(SHARED_PATH . '/header.php');
?>

<h2>Edit Trainer</h2>

<?php
	if ($trainer) {
		echo '<form method="post">';
		echo '<label>Name:</label><br>';
		echo '<input type="text" value="' . htmlspecialchars($trainer['name']) . '" disabled><br>';

		echo '<label>Email:</label><br>';
		echo '<input type="email" name="email" value="' . htmlspecialchars($trainer['email']) . '" required><br>';

		echo '<label>Location:</label><br>';
		echo '<input type="text" name="location" value="' . htmlspecialchars($trainer['location']) . '" required><br>';

		echo '<label>Certifications:</label><br>';
		echo '<input type="text" name="certifications" value="' . htmlspecialchars($trainer['certifications']) . '" required><br>';

		echo '<label>Years:</label><br>';
		echo '<input type="number" name="years" value="' . htmlspecialchars($trainer['years']) . '" required><br>';

		echo '<label>Specialization:</label><br>';
		echo '<input type="text" name="specialization" value="' . htmlspecialchars($trainer['specialization']) . '" required><br><br>';

		echo '<input type="submit" value="Update Trainer">';
		echo '</form>';
	} else {
		echo "<p>Trainer not found.</p>";
	}

	if (!empty($message)) {
		echo "<div class='alert'>" . htmlspecialchars($message) . "</div>";
	}

include(SHARED_PATH . '/footer.php');
?>
