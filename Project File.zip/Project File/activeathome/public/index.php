<!DOCTYPE html>
<html lang="en">
<head>
<!-- Page metadata and linking external CSS -->
<title>ActiveAtHome</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Link to the main stylesheet -->
<link rel=stylesheet type=text/css href=style.css>
</head>

	<body>
	
	<?php
		// Load initial configuration
		require_once('../private/initialize.php');
		// Include shared header file
		include(SHARED_PATH . '/header.php');
	?>
		
		<!-- Main content section -->
		<div class="main-content">
			<!-- Welcome heading -->
			<h1 style="text-align:center;">Welcome to ActiveAtHome</h1>
			
			<!-- Description box with system introduction -->
			<div class="description-box">
				<h3>
					<p>
						<strong>ActiveAtHome</strong> is a user-friendly web application designed to simplify the way people access fitness guidance.
						Whether you prefer to train from the comfort of your home or through online sessions, 
						this platform connects you with certified personal trainers who specialize in various fitness disciplines.
					</p>
					
					<!-- Unordered list of features -->
					<p>
						The system allows users to:
						<ul>
							<li>Browse available activities like yoga, Fitness, strength training, and Pilates</li>
							<li>View trainer profiles, including their certifications, experience, and specializations</li>
							<li>Add, update, or remove trainers through a secure admin interface</li>
							<li>Explore activity details for better decision-making</li>
						</ul>
					</p>
				</h3>
			</div>
		</div>
		<!-- Include shared footer file -->
		<?php include(SHARED_PATH . '/footer.php'); ?>
	
	</body>

</html>