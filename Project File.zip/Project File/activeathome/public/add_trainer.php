<?php
	// Load core configuration and initialize the system
	require_once('../private/initialize.php');
	$message = '';

	// Check if the form is submitted using POST method
	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		$new_trainer = [
			'name' => $_POST['name'] ?? '',
			'email' => $_POST['email'] ?? '',
			'location' => $_POST['location'] ?? '',
			'certifications' => $_POST['certifications'] ?? '',
			'years' => $_POST['years'] ?? '',
			'specialization' => $_POST['specialization'] ?? ''
		];
		// Call Trainer class method to insert data into the database
		$success = Trainer::create($db, $new_trainer);
		// Set appropriate message based on success/failure of the database operation
		$message = $success ? "Trainer added successfully!" : "Failed to add trainer.";
	}

	include(SHARED_PATH . '/header.php');
?>

<!-- Page Heading -->
<h2>Add New Trainer</h2>

<!-- Display success or error message if set -->
<?php if ($message): ?>
    <div class="alert"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<!-- Trainer Input Form -->
<form method="post">
    <label>Name:</label>
    <input type="text" name="name" required>

    <label>Email:</label>
    <input type="email" name="email" required>

    <label>Location:</label>
    <input type="text" name="location" required>

    <label>Certifications:</label>
    <input type="text" name="certifications" required>

    <label>Years of Experience:</label>
    <input type="number" name="years" required>

    <label>Specialization:</label>
    <input type="text" name="specialization" required>

    <input type="submit" value="Add Trainer">
</form>

<?php include(SHARED_PATH . '/footer.php'); ?>
