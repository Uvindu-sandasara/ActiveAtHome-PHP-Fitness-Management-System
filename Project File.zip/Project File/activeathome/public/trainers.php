<?php
	// Include all necessary initializations and database connection
	require_once('../private/initialize.php');
	// Fetch all trainers from the database
	$trainers = Trainer::all($db);
	// Check if a specific trainer ID is passed in the URL to display details
	$selected_id = $_GET['id'] ?? null;
	$selected_trainer = $selected_id ? Trainer::find_by_id($db, $selected_id) : null;

	// Include the common header section
	include(SHARED_PATH . '/header.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Trainer Management</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h2>List of Trainers</h2>

<!-- Trainer table listing all trainers -->
<table>
    
        <tr>
            <th>Name</th>
            <th>Action</th>
        </tr>
    
        <?php foreach ($trainers as $trainer): ?>
            <tr>
                <td><?= htmlspecialchars($trainer['name']) ?></td>
                <td>
					<!-- View: Pass trainer ID to reload and show details -->
                    <!-- Edit: Redirects to edit form -->
                    <!-- Delete: Asks for confirmation before deleting -->
                    <a href="trainers.php?id=<?= $trainer['id'] ?>">View</a> |
                    <a href="update_trainer.php?id=<?= $trainer['id'] ?>">Edit</a> |
                    <a href="delete_trainer.php?id=<?= $trainer['id'] ?>" onclick="return confirm('Are you sure you want to delete this trainer?');">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    
</table>

<?php if ($selected_trainer): ?>
	 <!-- Display selected trainer's full details -->
    <hr>
    <h3>Trainer Details</h3>

    <p><strong>Name:</strong> <?= htmlspecialchars($selected_trainer['name']) ?></p>
    <p><strong>Email:</strong> <?= htmlspecialchars($selected_trainer['email']) ?></p>
    <p><strong>Location:</strong> <?= htmlspecialchars($selected_trainer['location']) ?></p>
    <p><strong>Certifications:</strong> <?= htmlspecialchars($selected_trainer['certifications']) ?></p>
    <p><strong>Years:</strong> <?= htmlspecialchars($selected_trainer['years']) ?></p>
    <p><strong>Specialization:</strong> <?= htmlspecialchars($selected_trainer['specialization']) ?></p>
    
    <br>
    <a href="trainers.php" class="btn-back">← Back to Trainers</a>

<?php endif; ?>


<?php include(SHARED_PATH . '/footer.php'); ?>
