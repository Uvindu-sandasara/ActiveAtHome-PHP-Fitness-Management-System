<?php
	require_once __DIR__ . '/credentials.php';   // Load database credentials
	require_once __DIR__ . '/class_database.php';	// Include the custom Database class
	require_once __DIR__ . '/class_trainer.php';	// Include the Trainer class with the database
	require_once __DIR__ . '/class_activity.php';	// Include the Activity  class with database funtions for trainers
	require_once __DIR__ . '/database_functions.php';	// Include helper function for connecting to the database

	$database = db_connect(); // // Connect to the database using function 
	Database::set_database($database); // static reference
	$db = db_connect(); // Assign database connection
	
	define("SHARED_PATH", dirname(__DIR__) . '/shared');	// for header/footer includes

