<?php
	class Database {
		// Static property to hold the active database connection
		static protected $database;
		static protected $table_name = "";  // The table name for the subclass
		// List of column names in the associated table
		static protected $columns = ['id', 'name', 'email', 'location', 'certifications', 'years', 'specialization'];

		// Set the shared database connection
		static public function set_database($database) {
			self::$database = $database;
		}

		// Execute raw SQL query and return objects
		static public function find_by_sql($sql){
			$results = self::$database->query($sql);
			if(!$results) {
				exit("Database query failed. ");
			}
			$object_array=[];
			// Convert each row to an object
			while($record = $results->fetch_assoc()) {
				$object_array[] = static::instantiate($record);
			}
			return $object_array;
		}

		// Fetch all rows from the table
		static public function find_all() {
			$sql = "SELECT * FROM " . static::$table_name;
			return static::find_by_sql($sql);
		}

		// Fetch one row by ID
		static public function find_by_id($id) {
			$sql = "SELECT * FROM " . static::$table_name . " WHERE id='" . static::$database->escape_string($id) . "'";
			$result = static::find_by_sql($sql);
			if(!empty($result)){
				return array_shift($result);
			} else {
				echo "empty";
			}
		}

		// Convert a record (array) into an object of the calling class
		static protected function instantiate($record) {
			$object = new static;
			foreach($record as $property => $value) {
				if(property_exists($object, $property)){
					$object->$property=$value;
				}
			}
			return $object;
		}

		// Optional: used for simple login verification (if extended by Admin class)
		static public function verify_user($loginname, $password){
			$sql = "SELECT * FROM " . static::$table_name . " WHERE loginname='$loginname' AND password='$password' ";
			$result = static::find_by_sql($sql);
			return array_shift($result);
		}

		// Update the current object’s row in the database
		public function update() {
			$attributes = $this->attributes();  // Get all values
			$attribute_pairs=[];
			foreach($attributes as $key=>$value) {
				$attribute_pairs[] = "{$key}='{$value}'";
			}
			$sql = "UPDATE " . static::$table_name . " SET ";
			$sql .= join(', ', $attribute_pairs);
			$sql .= " WHERE id='". static::$database->escape_string($this->id) . "'";
			$results = static::$database->query($sql);
			return $results;
		}

		// Create a new row in the table using this object’s data
		public function create() {
			$attributes = $this->attributes();
			$sql = "INSERT INTO " . static::$table_name . " (";
			$sql .= join(', ', array_keys($attributes));
			$sql .= ") VALUES ('";
			$sql .= join("', '", array_values($attributes));
			$sql .= "')";
			$results = static::$database->query($sql);
			if($results) {
				$this->id = static::$database->insert_id;  // Save auto-incremented ID
			}
			return $results;
		}

		// Delete the current record from the database
		public function delete() {
			$sql = "DELETE FROM " . static::$table_name . " WHERE id='" . $this->id . "' LIMIT 1";
			$results = static::$database->query($sql);
			return $results;
		}

		// Collect non-ID attributes from object into an array
		public function attributes() {
			$attributes=[];
			foreach(static::$db_columns as $column) {
				if($column == 'id') { continue; }
				$attributes[$column] = $this->$column;
			}
			return $attributes;
		}

		// Update multiple properties at once (usually from form POST data)
		public function merge_attributes($args=[]) {
			foreach($args as $key=>$value) {
				if(property_exists($this, $key)) {
					$this->$key = $value;
				}
			}
		}
	}
?>