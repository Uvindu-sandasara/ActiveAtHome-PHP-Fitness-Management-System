<?php
	define("DB_SERVER", "localhost");  // Define the hostname of the database server
	define("DB_USER", "root");		   // Define the MySQL username used to connect to the database
	define("DB_PASS", "");			   // Define the MySQL password
	define("DB_NAME", "activeathome"); // Define the name of the database you want to connect
