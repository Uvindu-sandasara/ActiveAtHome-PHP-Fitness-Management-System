<?php

	class Activity {
		// Fetch all activity records from the database
		public static function all($db) {
			// Execute SQL query to get all records from the 'activities' table
			$result = $db->query("SELECT * FROM activities");
			$activities = [];
			// Loop through each row and add to the array
			while ($row = $result->fetch_assoc()) {
				$activities[] = $row;
			}

			return $activities;
		}
		// Find a single activity by its ID
		public static function find_by_id($db, $id) {
			// Prepare SQL statement to prevent SQL injection
			$stmt = $db->prepare("SELECT * FROM activities WHERE id = ?");
			// Bind the ID parameter as an integer
			$stmt->bind_param("i", $id);
			$stmt->execute();
			$result = $stmt->get_result();
			return $result->fetch_assoc();  
		}
	}
