<?php

	require_once('credentials.php'); // include this to access DB constants

	function db_connect() {    // database connection using MySQLi
		// Create a new MySQLi connection
		$database = new mysqli(DB_SERVER, DB_USER, DB_PASS, DB_NAME); 
		confirm_db_connect($database);  // Check the connection
		return $database;
	}

	// Function to confirm the DB connection is valid
	function confirm_db_connect($database) {
		if ($database->connect_errno > 0) {
			$msg = "Database connection failed: ";
			$msg .= $database->connect_error;
			$msg .= " (" . $database->connect_errno . ")";
			echo $msg;
			exit;
		}

		// Second check (can be removed — it's duplicate)
		if($database->connect_errno > 0) {
			$msg = "Database connection failed: ";
			$msg .= $database->connect_error;
			$msg .= " (" . $database->connect_errno . ")";
			echo $msg;
			echo "<br>";
		}
	}

?>