<?php

	class Trainer {

		// Fetch all trainers from the database
		public static function all($db) {
			$result = $db->query("SELECT * FROM trainers");
			$trainers = [];

			while ($row = $result->fetch_assoc()) {
				$trainers[] = $row;
			}

			return $trainers;
		}

		// Find a single trainer by their ID
		public static function find_by_id($db, $id) {
			$stmt = $db->prepare("SELECT * FROM trainers WHERE id = ?");
			$stmt->bind_param("i", $id);
			$stmt->execute();
			return $stmt->get_result()->fetch_assoc();
		}

		// Insert a new trainer into the database
		public static function create($db, $data) {
			$stmt = $db->prepare("INSERT INTO trainers (name, email, location, certifications, years, specialization) VALUES (?, ?, ?, ?, ?, ?)");
			$stmt->bind_param("ssssis", $data['name'], $data['email'], $data['location'], $data['certifications'], $data['years'], $data['specialization']);
			return $stmt->execute();
		}

		// Update a trainer’s email and certifications
		public static function update($db, $id, $data) {
			$stmt = $db->prepare("UPDATE trainers SET email = ?, certifications = ? WHERE id = ?");
			$stmt->bind_param("ssi", $data['email'], $data['certifications'], $id);
			return $stmt->execute();
		}

		// Delete a trainer from the database
		public static function delete($db, $id) {
			$stmt = $db->prepare("DELETE FROM trainers WHERE id = ?");
			$stmt->bind_param("i", $id);
			return $stmt->execute();
		}
	}