<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Meta and title setup -->
    <meta charset="UTF-8">
    <title>ActiveAtHome</title>
	<!-- Link to external CSS stylesheet -->
    <link rel="stylesheet" href="/activeathome/public/style.css">
</head>
<body>
	<!-- Page header section with large title -->
    <div class="page-header">
        <h1 style="font-size: 48px;">Active_At_Home</h1>
    </div>
	<!-- Layout row contains sidebar and main content area -->
    <div class="layout-row">
		<!-- Sidebar navigation -->
        <div class="sidebar">
            <nav class="main-nav">
			
				<!-- Navigation link to Home page -->
				<a href="/activeathome/public/index.php" class="<?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : '' ?>">Home</a>
				<a href="/activeathome/public/activities.php" class="<?= basename($_SERVER['PHP_SELF']) == 'activities.php' ? 'active' : '' ?>">Activities</a>
				<a href="/activeathome/public/trainers.php" class="<?= basename($_SERVER['PHP_SELF']) == 'trainers.php' ? 'active' : '' ?>">Trainers</a>
				<a href="/activeathome/public/add_trainer.php" class="<?= basename($_SERVER['PHP_SELF']) == 'add_trainer.php' ? 'active' : '' ?>">Add New Trainer</a>
			
			</nav>
        </div>
		
	<!-- This opens the main content section (to be closed in footer or individual pages) -->
    <div class="main-content">
