        </div> <!-- end main-content -->
    </div> <!-- end layout-row -->
	
	<!-- Footer section at the bottom of every page -->
    <footer>
        &copy; <?php echo date("Y"); ?> Active_At_Home | 5BUIS018C.2 BIS Development
    </footer>
</body>
</html>
