-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2025 at 04:46 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `activeathome`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `benefits` text DEFAULT NULL,
  `price` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `name`, `description`, `benefits`, `price`) VALUES
(1, 'Fitness', 'General fitness activities encompass a wide range of exercises aimed at improving overall health and well-being.', 'Improves cardiovascular health; supports weight management; enhances mental well-being; increases energy levels', 'From £30 per hour'),
(2, 'Strength Training', 'Strength training involves using resistance to build muscle strength and endurance.', 'Builds muscle mass; improves bone density; boosts metabolism; enhances overall physical performance', 'From £50 per 45 minutes'),
(3, 'Yoga', 'Mind-body practice that combines physical postures, breathing exercises, and meditation.', 'Improves flexibility and balance; reduces stress', 'From 35 per 45 minutes'),
(4, 'Pilates', 'Low-impact exercise that focuses on strengthening muscles while improving postural alignment and flexibility.', 'Strengthens core muscles; improves posture; increases flexibility: aids in injury recovery:', 'From 30 per 45 minutes');

-- --------------------------------------------------------

--
-- Table structure for table `trainers`
--

CREATE TABLE `trainers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `certifications` varchar(100) DEFAULT NULL,
  `years` int(11) DEFAULT NULL,
  `specialization` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trainers`
--

INSERT INTO `trainers` (`id`, `name`, `email`, `location`, `certifications`, `years`, `specialization`) VALUES
(12, 'Mary Brown', 'mary@may.com', 'NW3 only', 'Level 3', 3, 'Fitness, Yoga'),
(13, 'James White', 'james@james.com', 'SW1 and online', 'Level 3', 5, 'Fitness, Strength Training'),
(14, 'Ann Blue', 'ann@ann.com', 'Online only', 'ISSA', 5, 'Pilates, Strength Training'),
(15, 'Peter Red', 'peter@peter.com', 'NW2, NW3, NW4', 'Level 3', 4, 'Pilates');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trainers`
--
ALTER TABLE `trainers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `trainers`
--
ALTER TABLE `trainers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
